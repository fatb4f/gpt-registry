# Project Pack

Source: `metadata.yaml`

Notes:
- Canonical project registry metadata in Git.
- Rendered as Markdown for ChatGPT project-source compatibility.

```yaml
project:
  id: kernel
  name: Kernel
  status: active
  owners:
    - _404

registry:
  kind: gpt-project-registry-entry
  version: 0.1.0
  canonical_project_dir: kernel/project
  canonical_repo: fatb4f/kernel
  bundle_class: rag_registry
  canonical_instruction_ref: kernel/project/instructions.md
  canonical_source_manifest_ref: kernel/project/sources/manifest.yaml
  canonical_project_source_contract_ref: kernel/project/sources/project-sources.yaml

bundle:
  bundle_id: kernel-project-pack
  version: 0.1.0
  release_ref: kernel/project/bundle/release.json
  fingerprints_ref: kernel/project/bundle/fingerprints.json
  logic_validation_report_ref: kernel/project/bundle/logic-validation.report.json
  published_root: kernel/published
  current_pack_pointer_ref: kernel/published/project-pack.md

delivery:
  transport: google-drive-project-source
  mirror_policy: sync-published-pack-only
  drive_target: gdrive:OpenAI/ChatGPT/kernel/current
  drive_release_target: gdrive:OpenAI/ChatGPT/kernel/releases

instructions:
  canonical_ref: kernel/project/instructions.md
  applied_in_project_ui: false
  applied_version: pending

publication:
  last_published_at: 2026-03-27T19:26:48Z
  published_bundle_version: 0.1.0
  published_release_archive_ref: gdrive:OpenAI/ChatGPT/kernel/releases/kernel-project-pack-0.1.0.zip
  publish_status: published

visible_root_audit:
  publication_mode: sync-published-pack-only
  artifact_class: retrieval_bundle
  trust_boundary: non_authority
  validation_status: pass
  fingerprint_present: true
  fingerprint_mirrored: false
  human_gate_required: true
  review_record_present: false

notes:
  - This bundle is a RAG registry to fatb4f/kernel, not the full kernel authority plane.
  - project/ is the canonical human and tooling surface.
  - published/ is a flat markdown-oriented ChatGPT delivery surface.
  - instructions.md in project/ is canonical in git, while AGENTS.md is the bundled behavioral mirror for project retrieval.
  - ChatGPT Project UI instructions should be pasted from project/instructions.md when needed.
  - release and fingerprint artifacts remain local bundle outputs and are not mirrored into the ChatGPT-facing pack.

```
